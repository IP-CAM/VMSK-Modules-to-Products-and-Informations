<?php
// Heading
$_['heading_title']      = 'VMSK Modules to products';

// Text
// Text
$_['text_module']       = 'Модулі';
$_['text_success']      = 'Налаштування успішно змінено!';
$_['text_edit']         = 'Редактирование';

// Entry
$_['entry_name']        = 'Назва модуля';
$_['entry_title']       = 'Заголовок';
$_['entry_description'] = 'Опис';
$_['entry_status']      = 'Статус';

// Error
$_['error_permission']  = 'У вас недостатньо прав для внесення змін!';
$_['error_name']        = 'Назва має містити від 3 до 64 символів!';

