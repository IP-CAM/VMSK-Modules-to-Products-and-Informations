<?php
// Heading
$_['heading_title']      = 'VMSK Empty module';

// Text
// Text
$_['text_module']       = 'Модули';
$_['text_success']      = 'Настройки успешно изменены!';
$_['text_edit']         = 'Редактирование';

// Entry
$_['entry_name']        = 'Название модуля';
$_['entry_title']       = 'Заголовок';
$_['entry_description'] = 'Описание';
$_['entry_status']      = 'Статус';

// Error
$_['error_permission']  = 'У вас недостаточно прав для внесения изменений!';
$_['error_name']        = 'Название должно содержать от 3 до 64 символов!';

